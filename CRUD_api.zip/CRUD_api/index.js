//express boiler plate
const Product = require('./modles/product.modles.js');
const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
    res.send('Node Server Is Perfect wowow  ')
}); // brower site-screen

app.get('/api/products', async (req, res) => { // allprodcts
    try {
        const products = await Product.find({});
        res.status(200).json(products)
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
})

app.get('/api/product/:id', async (req, res) => { //seen single product id
    try {
        const { id } = req.params
        const products = await Product.findById(id)
        res.status(200).json(products)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
})

app.post('/api/products', async (req, res) => { // add products
    try {
        const products = await Product.create(req.body);
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
})

app.put('/api/products/:id', async (req, res) => { //update product
    try {
        const { id } = req.params;
        const update = req.body;
        const products = await Product.findByIdAndUpdate(id, update, { new: true })
        if (!products) {
            return res.status(404).json({ message: 'products not found yet.!' })
        }
        const UpDatedProduct = await Product.findById(id);
        res.status(200).json(UpDatedProduct)
    } catch (error) {
        res.status(500).json({ message: error.message })
    }
})

app.delete('/api/product/:id', async (req, res) => { // delete api
    try {
        const { id } = req.params;
        const product = await Product.findByIdAndDelete(id)
        if (!product) {
            return res.status(404).json({ message: 'product not found ..!!' })
        }
        res.status(200).json({ message: 'product Deleted.!', deleteProduct: product })
    } catch (error) {
        res.status(500).json({ message: error.message })
    }

})

mongoose.connect('mongodb+srv://ladbhavesh42:5thfebruary@cluster0.j66zzkc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    .then(() => {
        console.log('Connected to the database');
        app.listen(3000, () => {
            console.log("Server is running on port 3000");
        });
    })
    .catch((error) => {
        console.error('Error connecting to the database: ', error);
    });