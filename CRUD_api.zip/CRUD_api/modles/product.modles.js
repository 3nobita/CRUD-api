const mongoose = require('mongoose')

const ProductSchema = mongoose.Schema({
    name: {
        type: String,
        reuqired: [true, 'enter name :: '],
    },
    quantity: {
        type: Number,
        reuqired: [true, 'enter Number :: '],
        default: 0
    },
    price: {
        type: Number,
        reuqired: [true, 'enter price :: '],
        default: 0
    },
    image: {
        type: String,
        reuqired: false
    },
},
    {
        timestamps: true
    }


);

const Product = mongoose.model('Product', ProductSchema);
module.exports = Product;